from fastapi import APIRouter, Depends , Query
from sqlalchemy.orm import Session
from Config.database import get_db
from Model.models import Session as SessionModel
from Schemas.schemas import SessionCreate
router = APIRouter(
    prefix="/sessions",
    tags=["Sessions"]
)


@router.post("/")
def create_session(
    payload: SessionCreate,
    db: Session = Depends(get_db)
):
    new_session = SessionModel(
        user_id=payload.user_id
    )

    db.add(new_session)
    db.commit()
    db.refresh(new_session)

    return {
        "user_id": new_session.user_id,
        "session_uuid": new_session.session_uuid,
        "session_creation_status": "success"
    }


@router.get("/")
def get_sessions(
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    offset = (page - 1) * limit

    sessions = (
        db.query(SessionModel)
        .offset(offset)
        .limit(limit)
        .all()
    )

    total_records = db.query(SessionModel).count()

    return {
        "page": page,
        "limit": limit,
        "total_records": total_records,
        "total_pages": (total_records + limit - 1) // limit,
        "data": sessions
    }


@router.get("/{session_uuid}")
def get_session(
    session_uuid: str,
    db: Session = Depends(get_db)
):

    session = (
        db.query(SessionModel)
        .filter(
            SessionModel.session_uuid == session_uuid
        )
        .first()
    )

    return session

