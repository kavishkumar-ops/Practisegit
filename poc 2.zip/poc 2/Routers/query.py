from fastapi import APIRouter

from VectorDB.retrieval import search_documents
from VectorDB.llm import ask_llm

router = APIRouter(
    prefix="/query",
    tags=["Query"]
)


@router.post("/")
def ask_question(
    session_uuid: str,
    question: str
):

    results = search_documents(
        session_uuid,
        question
    )

    docs = results["documents"][0]

    context = "\n".join(docs)

    prompt = f"""
Answer only from the context.

Context:
{context}

Question:
{question}
"""

    answer = ask_llm(prompt)

    return {
        "session_uuid": session_uuid,
        "question": question,
        "answer": answer
    }