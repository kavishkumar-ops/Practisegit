from fastapi import APIRouter
from fastapi import UploadFile
from fastapi import File
from typing import List
from uuid import uuid4

from langchain_text_splitters import (
    RecursiveCharacterTextSplitter
)

from VectorDB.Chroma_db import collection
from VectorDB.Embeddings import create_embedding
from VectorDB.Document_loader import extract_text

router = APIRouter(
    prefix="/documents",
    tags=["Documents"]
)


@router.post("/upload")
async def upload_document(
    file:List[UploadFile] = File(...), 
    session_uuid: str = None
):

    text = extract_text(
        file.file,
        file.filename
    )

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = splitter.split_text(text)

    for index, chunk in enumerate(chunks):

        collection.add(
            ids=[str(uuid4())],
            documents=[chunk],
            embeddings=[
                create_embedding(chunk)
            ],
            metadatas=[
                {
                    "session_uuid": session_uuid,
                    "file_name": file.filename,
                    "chunk_number": index
                }
            ]
        )

    return {
        "status": "success",
        "chunks": len(chunks)
    }
    
    



@router.get("/check-embeddings")
def check_embeddings():

    results = collection.get(
        include=["embeddings", "documents", "metadatas"]
    )

    return results    