from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
import uuid

from Config.database import Base


class Session(Base):
    __tablename__ = "chat_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    session_uuid = Column(String,unique=True,nullable=False, default=lambda: str(uuid.uuid4()))
    created_date = Column(DateTime(timezone=True),server_default=func.now())
    status = Column(String,default="Active")