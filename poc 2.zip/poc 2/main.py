from fastapi import FastAPI

from Config.database import Base, engine
from Routers import Session
from Routers import documents
from Routers import query

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(Session.router)
app.include_router(documents.router)
app.include_router(query.router) 