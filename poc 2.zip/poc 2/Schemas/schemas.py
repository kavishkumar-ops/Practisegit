from pydantic import BaseModel


class QueryRequest(BaseModel):
    session_uuid: str
    question: str
    
    
class SessionCreate(BaseModel):
    user_id : int  