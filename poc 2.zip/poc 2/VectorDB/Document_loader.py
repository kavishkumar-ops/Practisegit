# from pypdf import PdfReader
# from docx import Document
# import xml.etree.ElementTree as ET


# def extract_pdf(file):

#     reader = PdfReader(file)

#     text = ""

#     for page in reader.pages:
#         if page.extract_text():
#             text += page.extract_text()

#     return text 

 
# def extract_docx(file):

#     doc = Document(file)

#     return "\n".join(
#         [p.text for p in doc.paragraphs]
#     )


# def extract_xml(file):

#     tree = ET.parse(file)

#     return ET.tostring(
#         tree.getroot(),
#         encoding="unicode"
#     )


# def extract_txt(file):

#     return file.read().decode(
#         "utf-8",
#         errors="ignore"
#     )


# def extract_text(file, filename):

#     filename = filename.lower()

#     if filename.endswith(".pdf"):
#         return extract_pdf(file)

#     if filename.endswith(".docx"):
#         return extract_docx(file)

#     if filename.endswith(".xml"):
#         return extract_xml(file)

#     if filename.endswith(".txt"):
#         return extract_txt(file)

#     raise Exception("Unsupported file type")  


import json
import csv
import io

from pypdf import PdfReader
from docx import Document
from bs4 import BeautifulSoup
from pptx import Presentation
from openpyxl import load_workbook
from striprtf.striprtf import rtf_to_text
import xml.etree.ElementTree as ET


def extract_pdf(file):

    reader = PdfReader(file)

    text = ""

    for page in reader.pages:
        if page.extract_text():
            text += page.extract_text()

    return text


def extract_docx(file):

    doc = Document(file)

    return "\n".join(
        [p.text for p in doc.paragraphs]
    )


def extract_pptx(file):

    prs = Presentation(file)

    text = []

    for slide in prs.slides:
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    line = "".join(run.text for run in para.runs)
                    if line.strip():
                        text.append(line)

    return "\n".join(text)


def extract_xlsx(file):

    wb = load_workbook(file, data_only=True)

    text = []

    for sheet in wb.worksheets:
        text.append(f"Sheet: {sheet.title}")
        for row in sheet.iter_rows(values_only=True):
            row_values = [str(cell) for cell in row if cell is not None]
            if row_values:
                text.append(", ".join(row_values))

    return "\n".join(text)


def extract_csv(file):

    content = file.read().decode("utf-8", errors="ignore")
    reader = csv.reader(io.StringIO(content))

    return "\n".join(
        [", ".join(row) for row in reader]
    )


def extract_txt(file):

    return file.read().decode(
        "utf-8",
        errors="ignore"
    )


def extract_html(file):

    soup = BeautifulSoup(
        file.read().decode("utf-8", errors="ignore"),
        "html.parser"
    )

    return soup.get_text(separator="\n").strip()


def extract_xml(file):

    tree = ET.parse(file)

    return ET.tostring(
        tree.getroot(),
        encoding="unicode"
    )


def extract_json(file):

    data = json.loads(file.read().decode("utf-8", errors="ignore"))

    return json.dumps(data, indent=2, ensure_ascii=False)


def extract_md(file):

    return file.read().decode("utf-8", errors="ignore")


def extract_rtf(file):

    raw = file.read().decode("utf-8", errors="ignore")

    return rtf_to_text(raw)


def extract_text(file, filename):

    filename = filename.lower()

    if filename.endswith(".pdf"):
        return extract_pdf(file)

    if filename.endswith(".docx"):
        return extract_docx(file)

    if filename.endswith(".pptx"):
        return extract_pptx(file)

    if filename.endswith(".xlsx"):
        return extract_xlsx(file)

    if filename.endswith(".csv"):
        return extract_csv(file)

    if filename.endswith(".txt"):
        return extract_txt(file)

    if filename.endswith(".html") or filename.endswith(".htm"):
        return extract_html(file)

    if filename.endswith(".xml"):
        return extract_xml(file)

    if filename.endswith(".json"):
        return extract_json(file)

    if filename.endswith(".md"):
        return extract_md(file)

    if filename.endswith(".rtf"):
        return extract_rtf(file)

    raise ValueError(
        f"Unsupported file type: '{filename}'. "
        f"Supported types: .pdf, .docx, .pptx, .xlsx, .csv, .txt, "
        f".html, .htm, .xml, .json, .md, .rtf"
    )