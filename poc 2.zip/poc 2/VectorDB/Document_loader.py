from pypdf import PdfReader
from docx import Document
import xml.etree.ElementTree as ET


def extract_pdf(file):

    reader = PdfReader(file)

    text = ""

    for page in reader.pages:
        if page.extract_text():
            text += page.extract_text()

    return text


def extract_docx(file):

    doc = Document(file)

    return "\n".join(
        [p.text for p in doc.paragraphs]
    )


def extract_xml(file):

    tree = ET.parse(file)

    return ET.tostring(
        tree.getroot(),
        encoding="unicode"
    )


def extract_txt(file):

    return file.read().decode(
        "utf-8",
        errors="ignore"
    )


def extract_text(file, filename):

    filename = filename.lower()

    if filename.endswith(".pdf"):
        return extract_pdf(file)

    if filename.endswith(".docx"):
        return extract_docx(file)

    if filename.endswith(".xml"):
        return extract_xml(file)

    if filename.endswith(".txt"):
        return extract_txt(file)

    raise Exception("Unsupported file type")