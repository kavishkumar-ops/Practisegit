from VectorDB.Chroma_db import collection
from VectorDB.Embeddings import create_embedding


def search_documents(
    session_uuid,
    question
):

    query_embedding = create_embedding(
        question
    )

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=5,
        where={
            "session_uuid": session_uuid
        }
    )

    return results